@extends('website.layouts.app')

@section('title', 'SHEV | עגלת קניות')

@section('headercolor')
<header class="alt-3 alt-3-short">
@stop

@section('content')
<div id="app">
    <payment></payment>
</div>
@endsection
