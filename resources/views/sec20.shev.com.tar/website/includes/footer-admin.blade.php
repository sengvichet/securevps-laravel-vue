<!--  FOOTER  -->
<footer>
<p class="copyright">© Copyright Shev, all rights reserved. </p>
</footer>
<!--  END OF FOOTER  -->
