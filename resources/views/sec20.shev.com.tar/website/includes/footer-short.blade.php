﻿<!--  FOOTER  -->
<footer class="footer-short">
<p class="copyright">© סולל יבוא ורשתות (1997) בע"מ. כל הזכויות שמורות. </p>
</footer>
<!--  END OF FOOTER  -->
