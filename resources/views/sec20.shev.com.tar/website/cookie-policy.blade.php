@extends('website.layouts.app')

@section('title', 'SHEV | עוגיות')

@section('headercolor')
    <header class="alt-3 alt-3-short">
        @stop

        @section('content')

            <div id="app">
                <cookie-policy></cookie-policy>
            </div>

@endsection
